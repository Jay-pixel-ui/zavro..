# Zavro — Product Requirements

## Overview
Premium futuristic AI startup / digital automation marketing website for **Zavro Solutions Pte Ltd** (Singapore). Cinematic, dark-mode, videogame-inspired UI with glassmorphism, neon glow, and AI-powered concierge.

Logo: `https://customer-assets.emergentagent.com/job_3cc09cc7-dfcd-433c-9f42-7030d33cf060/artifacts/7p8668yr_ChatGPT%20Image%20May%2015%2C%202026%2C%2003_30_54%20PM.png`

## Stack
- Frontend: React 19 + Tailwind + Framer Motion + shadcn/ui + lucide-react
- Backend: FastAPI + Motor (MongoDB) + Resend (email) + emergentintegrations (Claude Sonnet 4.5)
- Fonts: Unbounded (display), Outfit (body), JetBrains Mono (accents)

## User Personas
- **Founders / CMOs** — looking for an AI partner to engineer growth systems.
- **Operations leaders** — evaluating automation vendors.
- **Casual visitors** — judging credibility through visual polish.

## Core Requirements (Static)
1. Cinematic dark-mode marketing site with animated loading screen.
2. Floating glass navbar with active section indicator.
3. Hero with cinematic headline, two CTAs, hologram visual.
4. About + Services (7 cards bento) + AI Solutions + Marketing Solutions sections.
5. Animated workflow timeline (5 nodes, glowing connector line).
6. Animated counter stats backed by `/api/stats`.
7. Case studies (4 placeholders) and testimonials (3 with avatars).
8. Contact form persisted in MongoDB; Resend email when key present.
9. Floating AI chat assistant ("NOVA") powered by Claude Sonnet 4.5 with session persistence.
10. Neural-network canvas background + cursor glow + smooth scroll + scroll reveal.
11. Responsive (mobile-first); data-testid on every interactive element.

## What's Been Implemented — 2026-05-15
- ✅ Loading screen, cursor glow, neural canvas background
- ✅ Floating glass navbar (desktop + mobile menu)
- ✅ Hero, About, Services, AI Solutions, Marketing Solutions
- ✅ Workflow timeline w/ animated line + pulsing nodes
- ✅ Animated counter stats wired to `/api/stats`
- ✅ Case Studies (4 placeholders) + Testimonials (3 w/ avatars)
- ✅ Contact form → POST /api/contact (Mongo + optional Resend)
- ✅ Footer w/ social icon placeholders (Twitter, LinkedIn, Instagram, Facebook, YouTube, GitHub)
- ✅ AI chat bubble (NOVA) — POST /api/chat with **multi-turn context rehydration from Mongo**
- ✅ Backend tests: 14/14 passing after multi-turn fix

## Repositioning Update — 2026-05-15 (iteration 2)
- ✅ **Repositioned from "AI lab" → "Premium Digital Growth Agency"** (hero copy, badges, About tone)
- ✅ New hero copy: **"Build. Grow. Scale."**
- ✅ **6 services** rewritten for SMEs: Website Dev, Branding & Logo, Marketing, Social Media, Business Consultancy, AI Automation
- ✅ **Functional Learn More modals** (ServiceModal.jsx) with deliverables, "Ideal for" tags + Book Consultation / Discuss Project CTAs
- ✅ **Why Choose Us** section (6 reason cards) replacing redundant AI Solutions section
- ✅ Workflow updated: **Strategy → Design → Marketing → Automation → Growth**
- ✅ Marketing section softened and repositioned as "Outcomes"
- ✅ Chatbot SYSTEM_PROMPT rewritten for **concise replies (<70 words, no markdown headers)**
- ✅ Quick action chips always visible: Website Development · Branding · Marketing · Social Media · Automation · Book Consultation
- ✅ "Book Consultation" smart-action scrolls to contact form without an LLM round-trip
- ✅ **Admin page at `/admin`** — password-gated (X-Admin-Key header), lists all contact submissions
- ✅ Tests: **20/20 backend + 18/18 frontend acceptance criteria passing**

## Backend Endpoints
- `GET  /api/` — welcome
- `GET  /api/health` — config flags
- `GET  /api/stats` — animated counter source
- `POST /api/contact` — create contact (validates email)
- `GET  /api/contact` — list contacts (admin)
- `POST /api/chat` — Claude Sonnet 4.5; rehydrates session history from Mongo
- `GET  /api/chat/{session_id}/history` — chat transcript

## Environment Variables (backend/.env)
- `MONGO_URL`, `DB_NAME`, `CORS_ORIGINS` — protected
- `EMERGENT_LLM_KEY` — set (Universal Key)
- `RESEND_API_KEY` — **EMPTY** (user will add later; contact still saves to Mongo)
- `SENDER_EMAIL=onboarding@resend.dev`, `NOTIFICATION_EMAIL=hello@zavro.ai`

## P0 Backlog (next, when user supplies info)
- Add real social URLs (Twitter / LinkedIn / Instagram / Facebook / YouTube / GitHub)
- Add `RESEND_API_KEY` and verify domain for live email notifications
- Add real company contact email + phone

## P1 Backlog
- Lightweight admin page at `/admin` to view contacts (currently API-only)
- Case study detail pages (currently single-page only)
- Cookie/analytics consent banner

## P2 Backlog
- Multi-language (EN/ZH given Singapore market)
- Blog / Insights section with MDX
- Soft rate-limit on /api/chat per session_id
