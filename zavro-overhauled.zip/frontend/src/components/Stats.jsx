import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import axios from "axios";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

function AnimatedCounter({ value, suffix = "", decimals = 0 }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    const duration = 1600;
    const tick = (t) => {
      const p = Math.min((t - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(Number((eased * value).toFixed(decimals)));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [inView, value, decimals]);

  return (
    <span ref={ref} className="font-display text-5xl sm:text-6xl lg:text-7xl gradient-text">
      {decimals > 0 ? display.toFixed(decimals) : Math.floor(display).toLocaleString()}
      {suffix}
    </span>
  );
}

const FALLBACK = { projects: 84, automations: 320, clients: 47, uptime: 99.98 };

export default function Stats() {
  const [s, setS] = useState(FALLBACK);

  useEffect(() => {
    let active = true;
    axios
      .get(`${API}/stats`)
      .then((r) => {
        if (active && r.data) setS(r.data);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, []);

  const items = [
    { label: "AI systems shipped", value: s.projects, suffix: "+" },
    { label: "Automations live", value: s.automations, suffix: "+" },
    { label: "Clients worldwide", value: s.clients, suffix: "+" },
    { label: "Production uptime", value: s.uptime, suffix: "%", decimals: 2 },
  ];

  return (
    <section
      id="stats"
      className="relative py-24 sm:py-32 border-y border-white/5"
      data-testid="stats-section"
    >
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 grid-bg opacity-30" />
      </div>

      <div className="relative max-w-7xl mx-auto px-5 sm:px-8 grid grid-cols-2 lg:grid-cols-4 gap-y-12 gap-x-6">
        {items.map((it, i) => (
          <motion.div
            key={it.label}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, delay: i * 0.08 }}
            className="text-center lg:text-left"
            data-testid={`stat-${i}`}
          >
            <AnimatedCounter
              value={it.value}
              suffix={it.suffix || ""}
              decimals={it.decimals || 0}
            />
            <p className="mt-3 font-mono-accent text-[11px] text-slate-400">{it.label}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
