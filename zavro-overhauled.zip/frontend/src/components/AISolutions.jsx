import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";
import { IMG } from "@/lib/constants";

const FEATURES = [
  "Custom multi-agent workflows for ops, sales, finance",
  "Document intelligence: extract, classify, route, action",
  "Inbox + ticket triage with human-in-the-loop fallback",
  "Real-time observability and cost tracking per agent",
  "Compliance-aware: PII redaction, audit trails, RBAC",
];

export default function AISolutions() {
  return (
    <section
      id="ai-solutions"
      className="relative py-28 sm:py-36"
      data-testid="ai-solutions-section"
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8 grid lg:grid-cols-12 gap-12 items-center">
        {/* Visual */}
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8 }}
          className="lg:col-span-6 relative"
        >
          <div className="relative aspect-square rounded-3xl overflow-hidden border-glow">
            <img src={IMG.abstract2} alt="" className="w-full h-full object-cover opacity-80" />
            <div className="absolute inset-0 bg-gradient-to-tr from-[#02040A] via-transparent to-purple-500/10" />

            {/* HUD overlays */}
            <div className="absolute top-5 left-5 right-5 flex items-center justify-between">
              <p className="font-mono-accent text-[10px] text-cyan-300">AGENT::AUTONOMY_03</p>
              <span className="flex items-center gap-1.5 text-[10px] font-mono-accent text-emerald-300">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                LIVE
              </span>
            </div>
            <div className="absolute bottom-6 left-6 right-6 glass rounded-xl p-4">
              <div className="flex items-center justify-between">
                <p className="font-mono-accent text-[10px] text-slate-400">Latency p95</p>
                <p className="font-mono-accent text-xs text-cyan-200">312 ms</p>
              </div>
              <div className="mt-2 h-1 bg-white/5 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-cyan-400 to-amber-300"
                  initial={{ width: 0 }}
                  whileInView={{ width: "78%" }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.2 }}
                />
              </div>
              <div className="mt-3 flex items-center justify-between">
                <p className="font-mono-accent text-[10px] text-slate-400">Tasks executed</p>
                <p className="font-mono-accent text-xs text-amber-200">12,847 / hr</p>
              </div>
            </div>
          </div>
          <div className="absolute -top-12 -left-12 w-56 h-56 bg-purple-500/15 blur-3xl rounded-full pointer-events-none" />
        </motion.div>

        {/* Copy */}
        <motion.div
          initial={{ opacity: 0, x: 24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8 }}
          className="lg:col-span-6"
        >
          <p className="font-mono-accent text-[11px] text-cyan-300/90">
            [ 03 — AI Automation Solutions ]
          </p>
          <h2 className="mt-4 font-display text-4xl sm:text-5xl lg:text-6xl leading-[1.05] text-white">
            Automation that <span className="gradient-text">earns its keep</span>.
          </h2>
          <p className="mt-5 text-slate-300/90 max-w-xl">
            We deploy AI agents into the heart of your operations — measured by hours
            saved, errors prevented, and revenue accelerated. Not novelty. Throughput.
          </p>

          <ul className="mt-8 space-y-3.5">
            {FEATURES.map((f, i) => (
              <motion.li
                key={f}
                initial={{ opacity: 0, x: 12 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06, duration: 0.5 }}
                className="flex items-start gap-3 text-slate-200"
              >
                <CheckCircle2
                  size={18}
                  className="mt-0.5 text-cyan-300 shrink-0 drop-shadow-[0_0_8px_rgba(0,229,255,0.6)]"
                />
                <span className="text-sm sm:text-base">{f}</span>
              </motion.li>
            ))}
          </ul>
        </motion.div>
      </div>
    </section>
  );
}
