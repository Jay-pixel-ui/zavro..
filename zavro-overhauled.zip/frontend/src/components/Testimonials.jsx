import { motion } from "framer-motion";
import { Quote } from "lucide-react";

const TESTIMONIALS = [
  {
    quote:
      "Zavro built us an underwriting co-pilot that quietly does the work of three analysts. It's the most defensible system we've ever shipped.",
    name: "Mei-Lin Chua",
    role: "COO, Aurora Capital",
    avatar:
      "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=200&w=200&q=80",
  },
  {
    quote:
      "Their approach feels less like an agency and more like an engineering partner. Everything is measurable, observable, defensible.",
    name: "Daniel Okafor",
    role: "Founder, Helix Health",
    avatar:
      "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=200&w=200&q=80",
  },
  {
    quote:
      "We tripled qualified pipeline in 90 days without adding a single SDR. Zavro's outbound engine is genuinely a category-of-one.",
    name: "Priya Raman",
    role: "Head of Growth, Meridian",
    avatar:
      "https://images.unsplash.com/photo-1544005313-94ddf0286df2?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=200&w=200&q=80",
  },
];

export default function Testimonials() {
  return (
    <section
      id="testimonials"
      className="relative py-28 sm:py-36"
      data-testid="testimonials-section"
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="max-w-3xl"
        >
          <p className="font-mono-accent text-[11px] text-cyan-300/90">[ 07 — Testimonials ]</p>
          <h2 className="mt-4 font-display text-4xl sm:text-5xl lg:text-6xl leading-[1.05] text-white">
            Trusted by teams who <span className="gradient-text">ship</span>.
          </h2>
        </motion.div>

        <div className="mt-14 grid md:grid-cols-3 gap-5">
          {TESTIMONIALS.map((t, i) => (
            <motion.figure
              key={t.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="tilt-card glass rounded-2xl p-6 sm:p-7 relative"
              data-testid={`testimonial-${i}`}
            >
              <Quote
                size={22}
                className="text-cyan-300/70 drop-shadow-[0_0_10px_rgba(0,229,255,0.4)]"
              />
              <blockquote className="mt-4 text-[15px] sm:text-base text-slate-200 leading-relaxed">
                "{t.quote}"
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-3">
                <img
                  src={t.avatar}
                  alt={t.name}
                  className="w-10 h-10 rounded-full object-cover border border-cyan-400/40"
                />
                <div>
                  <p className="text-sm text-white font-medium">{t.name}</p>
                  <p className="font-mono-accent text-[10px] text-slate-400">{t.role}</p>
                </div>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
