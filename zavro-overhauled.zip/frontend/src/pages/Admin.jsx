import { useEffect, useState } from "react";
import axios from "axios";
import { motion } from "framer-motion";
import { Lock, RefreshCcw, Mail, Calendar, Briefcase, Inbox } from "lucide-react";
import { LOGO_URL } from "@/lib/constants";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;
const STORAGE_KEY = "zavro_admin_key";

export default function Admin() {
  const [authed, setAuthed] = useState(false);
  const [key, setKey] = useState("");
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const stored = sessionStorage.getItem(STORAGE_KEY);
    if (stored) {
      setKey(stored);
      load(stored);
    }
  }, []);

  const load = async (k) => {
    setLoading(true);
    setError("");
    try {
      const { data } = await axios.get(`${API}/contact`, {
        headers: { "X-Admin-Key": k },
      });
      setContacts(data);
      setAuthed(true);
      sessionStorage.setItem(STORAGE_KEY, k);
    } catch (e) {
      setError("Invalid admin key. Try again.");
      setAuthed(false);
      sessionStorage.removeItem(STORAGE_KEY);
    } finally {
      setLoading(false);
    }
  };

  const submit = (e) => {
    e.preventDefault();
    if (key.trim()) load(key.trim());
  };

  const logout = () => {
    sessionStorage.removeItem(STORAGE_KEY);
    setAuthed(false);
    setContacts([]);
    setKey("");
  };

  return (
    <div className="min-h-screen bg-[#02040A] text-white">
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 aurora opacity-60" />
        <div className="absolute inset-0 grid-bg opacity-40" />
      </div>

      <header className="relative z-10 max-w-6xl mx-auto px-5 sm:px-8 pt-8 pb-6 flex items-center justify-between">
        <a href="/" className="flex items-center gap-3 magnetic" data-testid="admin-home-link">
          <img src={LOGO_URL} alt="Zavro" className="w-9 h-9 rounded-lg object-cover glow-cyan" />
          <div>
            <p className="font-display text-sm tracking-[0.2em] text-white">ZAVRO</p>
            <p className="font-mono-accent text-[10px] text-cyan-300/80">Admin Console</p>
          </div>
        </a>
        {authed && (
          <button
            onClick={logout}
            className="font-mono-accent text-[10px] px-3 py-2 rounded-lg border border-white/10 text-slate-300 hover:text-white hover:border-cyan-400/40 hover:bg-cyan-400/5 transition-all"
            data-testid="admin-logout"
          >
            Logout
          </button>
        )}
      </header>

      <main className="relative z-10 max-w-6xl mx-auto px-5 sm:px-8 pb-20">
        {!authed ? (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-16 max-w-md mx-auto glass-strong rounded-3xl p-8 border-glow"
          >
            <div className="w-12 h-12 rounded-xl bg-cyan-400/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300 mb-5">
              <Lock size={18} />
            </div>
            <h1 className="font-display text-2xl text-white">Admin access</h1>
            <p className="mt-2 text-sm text-slate-400">
              Enter your admin key to view contact form submissions.
            </p>

            <form onSubmit={submit} className="mt-7 space-y-4">
              <input
                type="password"
                value={key}
                onChange={(e) => setKey(e.target.value)}
                placeholder="Admin key"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-slate-500 outline-none focus:border-cyan-400/50 focus:bg-white/10 transition-all"
                data-testid="admin-key-input"
                autoFocus
              />
              {error && (
                <p className="text-xs text-red-400" data-testid="admin-error">
                  {error}
                </p>
              )}
              <button
                type="submit"
                disabled={loading || !key.trim()}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl text-sm font-mono-accent text-[#02040A] bg-gradient-to-r from-cyan-300 to-amber-300 hover:from-cyan-200 hover:to-amber-200 transition-all disabled:opacity-50 shadow-[0_0_28px_rgba(0,229,255,0.35)]"
                data-testid="admin-submit"
              >
                {loading ? "Unlocking…" : "Unlock"}
              </button>
            </form>
          </motion.div>
        ) : (
          <div className="mt-6">
            <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
              <div>
                <h1 className="font-display text-3xl sm:text-4xl text-white">
                  Contact submissions
                </h1>
                <p className="mt-1 text-sm text-slate-400">
                  {contacts.length} total · sorted by newest first
                </p>
              </div>
              <button
                onClick={() => load(key)}
                disabled={loading}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-mono-accent text-cyan-200 border border-cyan-400/30 hover:border-cyan-300/70 hover:text-white hover:bg-cyan-400/5 transition-all disabled:opacity-50"
                data-testid="admin-refresh"
              >
                <RefreshCcw size={14} className={loading ? "animate-spin" : ""} />
                Refresh
              </button>
            </div>

            {contacts.length === 0 ? (
              <div className="glass rounded-3xl p-14 text-center">
                <Inbox size={32} className="mx-auto text-slate-500" />
                <p className="mt-4 text-slate-400">No submissions yet.</p>
              </div>
            ) : (
              <div className="grid gap-4">
                {contacts.map((c, i) => (
                  <motion.div
                    key={c.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.03 }}
                    className="glass rounded-2xl p-6"
                    data-testid={`admin-contact-${i}`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <h3 className="font-display text-lg text-white">{c.name}</h3>
                        <a
                          href={`mailto:${c.email}`}
                          className="inline-flex items-center gap-1.5 text-sm text-cyan-300 hover:text-amber-300 transition-colors mt-1"
                        >
                          <Mail size={13} />
                          {c.email}
                        </a>
                      </div>
                      <div className="text-right">
                        <p className="font-mono-accent text-[10px] text-slate-400 flex items-center gap-1.5">
                          <Calendar size={11} />
                          {new Date(c.created_at).toLocaleString()}
                        </p>
                        <p
                          className={`font-mono-accent text-[10px] mt-1 ${
                            c.email_sent ? "text-emerald-300" : "text-slate-500"
                          }`}
                        >
                          {c.email_sent ? "EMAIL SENT" : "STORED ONLY"}
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 flex flex-wrap gap-2">
                      {c.company && (
                        <span className="text-xs px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-slate-300">
                          <Briefcase size={11} className="inline mr-1" />
                          {c.company}
                        </span>
                      )}
                      {c.service && (
                        <span className="text-xs px-2.5 py-1 rounded-full bg-cyan-400/5 border border-cyan-400/30 text-cyan-200">
                          {c.service}
                        </span>
                      )}
                    </div>

                    <p className="mt-4 text-sm text-slate-300 leading-relaxed whitespace-pre-wrap border-l-2 border-cyan-400/30 pl-4">
                      {c.message}
                    </p>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
