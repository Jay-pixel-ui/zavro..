# Zavro App Handoff for Ollama / Another Tool

This document is a structured context bundle for the current Zavro project. It is written for another agent or tool to understand the codebase, architecture, environment requirements, runtime behavior, current customization state, and the exact files that matter.

Important note: this repository is a full-stack site with a React frontend and a FastAPI backend. The frontend currently contains a custom, non-Emergent shell with local asset replacements and no visible Emergent badge/watermark.

---

## 1. Project Summary

Project name: Zavro

Purpose:
- A premium AI automation and digital growth agency website.
- Includes marketing-focused landing pages, a contact form, an AI chat concierge, and an admin page.
- Uses a React frontend and a FastAPI backend with MongoDB persistence.

Primary business areas:
- Website development
- Branding and logo design
- Marketing solutions
- Social media management
- Business consultancy
- AI automation and integrations

Primary user-facing experience:
- Landing page with hero, about, services, why choose us, workflow, marketing, stats, case studies, testimonials, contact, and footer sections.
- Floating AI chat assistant called NOVA.
- Admin page for reviewing contacts.

---

## 2. Repository Structure

Root:
- [README.md](README.md)
- [design_guidelines.json](design_guidelines.json)
- [full_project_dump.txt](full_project_dump.txt)
- [test_result.md](test_result.md)
- [backend/](backend/)
- [frontend/](frontend/)
- [memory/](memory/)
- [tests/](tests/)
- [test_reports/](test_reports/)

Backend:
- [backend/server.py](backend/server.py)
- [backend/requirements.txt](backend/requirements.txt)
- [backend/tests/](backend/tests/)
- [backend/tests/conftest.py](backend/tests/conftest.py)
- [backend/tests/test_zavro_backend.py](backend/tests/test_zavro_backend.py)

Frontend:
- [frontend/package.json](frontend/package.json)
- [frontend/craco.config.js](frontend/craco.config.js)
- [frontend/jsconfig.json](frontend/jsconfig.json)
- [frontend/components.json](frontend/components.json)
- [frontend/postcss.config.js](frontend/postcss.config.js)
- [frontend/tailwind.config.js](frontend/tailwind.config.js)
- [frontend/public/](frontend/public/)
- [frontend/src/](frontend/src/)
- [frontend/src/App.js](frontend/src/App.js)
- [frontend/src/index.js](frontend/src/index.js)
- [frontend/src/index.css](frontend/src/index.css)
- [frontend/src/App.css](frontend/src/App.css)
- [frontend/src/components/](frontend/src/components/)
- [frontend/src/components/ui/](frontend/src/components/ui/)
- [frontend/src/hooks/](frontend/src/hooks/)
- [frontend/src/lib/](frontend/src/lib/)
- [frontend/src/pages/](frontend/src/pages/)

---

## 3. Tech Stack

Frontend:
- React 19
- React Router DOM
- Tailwind CSS
- CRACO
- Framer Motion
- Lucide React
- Axios
- Radix UI primitives
- ShadCN-style UI components

Backend:
- FastAPI
- Uvicorn
- Motor (async MongoDB driver)
- Pydantic
- Python-dotenv
- Resend for email
- Emergent integrations for LLM chat
- Pytest

Runtime assumptions:
- Node.js and npm are used for the frontend
- Python is used for the backend
- MongoDB must be available through MONGO_URL
- The backend uses environment variables for LLM and email configuration

---

## 4. Environment Variables

Backend environment variables expected by [backend/server.py](backend/server.py):

- MONGO_URL
  - Required
  - Example format: mongodb://localhost:27017 or a cloud MongoDB URI
- DB_NAME
  - Required
  - Database name for app collections
- EMERGENT_LLM_KEY
  - Optional for local development if chat is disabled
  - If missing, the chat endpoint returns 503
- RESEND_API_KEY
  - Optional
  - If missing, contact email sending will silently fail and email_sent will be False
- SENDER_EMAIL
  - Optional default: onboarding@resend.dev
- NOTIFICATION_EMAIL
  - Optional default: hello@zavro.ai
- ADMIN_KEY
  - Optional default: zavro-admin-2026
- CORS_ORIGINS
  - Optional
  - Comma-separated origins; default is *

Frontend environment variables:
- REACT_APP_BACKEND_URL
  - Used by [frontend/src/components/AIChatBubble.jsx](frontend/src/components/AIChatBubble.jsx)
  - Must point to the backend base URL, such as http://localhost:8000

---

## 5. How the App Runs

### Backend

Start command conceptually:
- cd backend
- python -m uvicorn server:app --reload --host 0.0.0.0 --port 8000

Operational behavior:
- Exposes API routes under /api
- Uses MongoDB collections for contacts and chat messages
- Handles contact form submission and AI chat requests

### Frontend

Start command conceptually:
- cd frontend
- npm install --legacy-peer-deps
- npm run start -- --host 127.0.0.1 --port 3000

Expected local URL:
- http://127.0.0.1:3000
- http://localhost:3000

---

## 6. Key Backend File Details

### [backend/server.py](backend/server.py)

This is the main backend entry point.

Core responsibilities:
- Initialize FastAPI app and router
- Load environment variables
- Connect to MongoDB
- Define request/response models
- Expose health route and stats route
- Accept contact submissions and store them in MongoDB
- Send email notifications via Resend when configured
- Power the AI assistant chat flow using LLM integration
- Store chat history per session
- Expose admin-only read access to contacts

Important models:
- ContactCreate
- Contact
- ChatRequest
- ChatResponse
- ChatMessage

Important routes:
- GET /api/
  - Health/identity route
- GET /api/health
  - Checks whether Resend and LLM are configured
- POST /api/contact
  - Stores contact form data and optionally sends email
- GET /api/contact
  - Admin-only listing of contact records
- POST /api/chat
  - Accepts a session_id and a message
  - Rehydrates chat history for that session
  - Persists the user message
  - Calls the LLM and stores assistant response
- GET /api/chat/{session_id}/history
  - Returns chat history for a session
- GET /api/stats
  - Returns static business stats used on the frontend

Important logic details:
- The chat flow uses a deterministic system prompt for NOVA.
- Chat history is reloaded before each new message so context survives across turns.
- The backend does not leak MongoDB _id fields in JSON responses.
- The app closes the MongoDB client on shutdown.

### [backend/requirements.txt](backend/requirements.txt)

Lists the Python dependencies required to run the backend.

Important packages:
- fastapi
- uvicorn
- motor
- pydantic
- python-dotenv
- resend
- emergentintegrations
- pytest
- python-multipart

### [backend/tests/test_zavro_backend.py](backend/tests/test_zavro_backend.py)

This file contains regression tests for the backend.

Covered areas:
- Health endpoint
- Stats endpoint
- Contact creation and validation
- Contact listing and admin auth
- Chat single-turn and multi-turn behavior
- Chat history persistence
- No-_id leak checks
- Chat brevity rules

Important behavior under test:
- Chat context should persist across multiple requests for the same session_id
- The backend should not expose MongoDB _id values
- The assistant response should stay concise and not include markdown headers

---

## 7. Key Frontend File Details

### [frontend/src/index.js](frontend/src/index.js)

Entry file for React.

Responsibilities:
- Creates the root React DOM element
- Imports [frontend/src/index.css](frontend/src/index.css)
- Renders [frontend/src/App.js](frontend/src/App.js)

### [frontend/src/App.js](frontend/src/App.js)

Main app component.

Responsibilities:
- Imports all layout sections and shared UI components
- Renders a full landing page for /
- Renders the Admin page at /admin
- Uses React Router for route handling
- Mounts the global loading screen, cursor glow, neural background, navbar, footer, AI chat, and toaster

Main layout sections:
- Hero
- About
- Services
- WhyChooseUs
- Workflow
- MarketingSolutions
- Stats
- CaseStudies
- Testimonials
- Contact
- Footer
- AIChatBubble

### [frontend/src/lib/constants.js](frontend/src/lib/constants.js)

Shared constants and asset references.

Current state after customization:
- Uses local SVG assets instead of old Emergent-hosted image URLs
- Exposes:
  - LOGO_URL
  - IMG.heroBg
  - IMG.workflowBg
  - IMG.dashboard
  - IMG.aiAvatar
  - IMG.abstract1
  - IMG.abstract2
  - NAV_LINKS
  - SOCIAL_LINKS
  - COMPANY

### [frontend/package.json](frontend/package.json)

Defines the frontend scripts and dependencies.

Scripts:
- start -> craco start
- build -> craco build
- test -> craco test

Important dependency note:
- The project was adjusted to remove the Emergent visual-edits dependency and rely on local assets instead.

### [frontend/craco.config.js](frontend/craco.config.js)

CRACO config for the React app.

Responsibilities:
- Sets up path aliases so imports use @/style paths
- Configures webpack watch options
- Supports optional health-check plugin integration
- No longer includes the Emergent visual edits integration

### [frontend/public/index.html](frontend/public/index.html)

The HTML shell for the app.

Responsibilities:
- Sets title and meta description
- Loads fonts and the favicon
- Contains the root div for React
- No longer includes the old Emergent badge or watermark injection

### [frontend/public/favicon.svg](frontend/public/favicon.svg)

Custom local favicon.

### [frontend/public/images/](frontend/public/images/)

Contains local SVG assets used by the app:
- hero-bg.svg
- workflow-bg.svg
- dashboard-preview.svg
- ai-avatar.svg

These were introduced to replace old Emergent-hosted assets.

---

## 8. Frontend Component Map

### [frontend/src/components/Hero.jsx](frontend/src/components/Hero.jsx)

The hero section.

Responsibilities:
- Shows the landing hero content
- Displays a large headline and CTA buttons
- Uses animated motion effects
- Uses the hero background image from constants

### [frontend/src/components/About.jsx](frontend/src/components/About.jsx)

About section.

### [frontend/src/components/Services.jsx](frontend/src/components/Services.jsx)

Service cards and service highlights.

### [frontend/src/components/WhyChooseUs.jsx](frontend/src/components/WhyChooseUs.jsx)

Reasons to choose Zavro.

### [frontend/src/components/MarketingSolutions.jsx](frontend/src/components/MarketingSolutions.jsx)

Marketing-focused solution highlight area.

### [frontend/src/components/Workflow.jsx](frontend/src/components/Workflow.jsx)

Process/workflow breakdown.

### [frontend/src/components/Stats.jsx](frontend/src/components/Stats.jsx)

Animated stats section.

### [frontend/src/components/CaseStudies.jsx](frontend/src/components/CaseStudies.jsx)

Showcase cards with case-study-like examples.

### [frontend/src/components/Testimonials.jsx](frontend/src/components/Testimonials.jsx)

Client testimonials block.

### [frontend/src/components/Contact.jsx](frontend/src/components/Contact.jsx)

Contact form UI.

Behavioral note:
- Likely posts to the backend contact endpoint.

### [frontend/src/components/Footer.jsx](frontend/src/components/Footer.jsx)

Footer content and navigation.

### [frontend/src/components/Navbar.jsx](frontend/src/components/Navbar.jsx)

Top navigation.

### [frontend/src/components/LoadingScreen.jsx](frontend/src/components/LoadingScreen.jsx)

Initial full-screen loading overlay shown before the app finishes its intro sequence.

### [frontend/src/components/CursorGlow.jsx](frontend/src/components/CursorGlow.jsx)

Cursor-following visual effect.

### [frontend/src/components/NeuralBackground.jsx](frontend/src/components/NeuralBackground.jsx)

Ambient background animated layer.

### [frontend/src/components/ServiceModal.jsx](frontend/src/components/ServiceModal.jsx)

Modal for presenting a specific service in more detail.

### [frontend/src/components/AIChatBubble.jsx](frontend/src/components/AIChatBubble.jsx)

The floating AI assistant UI.

Responsibilities:
- Maintains a session_id in sessionStorage
- Opens/closes the chat panel
- Sends messages to the backend /api/chat endpoint
- Supports quick prompts
- Handles the “Book Consultation” action by scrolling to the contact form
- Displays loading state and message history
- Uses the local AI avatar image from constants

Important logic details:
- Uses axios to POST to `${BACKEND_URL}/api/chat`
- The backend URL comes from REACT_APP_BACKEND_URL
- Quick prompts are hardcoded as: Website Development, Branding, Marketing, Social Media, Automation, Book Consultation
- If the backend returns an error, it shows a fallback offline message

### [frontend/src/pages/Admin.jsx](frontend/src/pages/Admin.jsx)

Admin page.

Responsibilities:
- Presents a simple admin interface for viewing contact submissions
- Likely calls the secured backend route /api/contact with an admin header

---

## 9. Current Customization State

The frontend has been customized to remove the old Emergent branding footprint.

What was changed:
- Removed the visible Emergent badge/watermark injection from the HTML shell
- Removed the emergent visual edits integration from the CRACO config
- Replaced Emergent-hosted images with local SVG assets
- Replaced the old favicon with a local SVG favicon
- Updated the HTML metadata to present the site as Zavro rather than an Emergent product

Current important files changed in the working tree:
- [frontend/craco.config.js](frontend/craco.config.js)
- [frontend/package.json](frontend/package.json)
- [frontend/public/index.html](frontend/public/index.html)
- [frontend/src/lib/constants.js](frontend/src/lib/constants.js)
- [frontend/public/favicon.svg](frontend/public/favicon.svg)
- [frontend/public/images/hero-bg.svg](frontend/public/images/hero-bg.svg)
- [frontend/public/images/workflow-bg.svg](frontend/public/images/workflow-bg.svg)
- [frontend/public/images/dashboard-preview.svg](frontend/public/images/dashboard-preview.svg)
- [frontend/public/images/ai-avatar.svg](frontend/public/images/ai-avatar.svg)
- [full_project_dump.txt](full_project_dump.txt)

---

## 10. Known Warnings / Notes

There are non-blocking warnings during frontend build/run:
- Tailwind class ambiguity warning for duration-[1200ms]
- Node deprecation warnings from webpack dev server internals

These do not block the app from building or running.

---

## 11. Verified Commands

Frontend build was verified successfully earlier in this session:
- cd frontend
- npm install --legacy-peer-deps
- npm run build

Observed result:
- Build completed successfully with “Compiled successfully.”

---

## 12. Suggested Next Tasks for Another Tool

If another tool is going to continue work, it should preserve the following:
- The local asset setup in [frontend/src/lib/constants.js](frontend/src/lib/constants.js)
- The removal of Emergent UI injection from [frontend/public/index.html](frontend/public/index.html)
- The use of [frontend/public/favicon.svg](frontend/public/favicon.svg)
- The backend environment variables in [backend/server.py](backend/server.py)
- The AI chat flow in [frontend/src/components/AIChatBubble.jsx](frontend/src/components/AIChatBubble.jsx)
- The backend API routes in [backend/server.py](backend/server.py)

If the next task is deployment, ensure:
- The frontend is built with the correct backend URL in REACT_APP_BACKEND_URL
- The backend is deployed with valid MongoDB and LLM credentials
- The admin key is kept secure

---

## 13. Short Working Summary for Another Tool

If you want a one-paragraph handoff summary:

This is a Zavro marketing website with a React frontend and a FastAPI backend. The frontend is a polished single-page experience with animated sections, a floating AI assistant, and an admin route; the backend handles contact submission, email notifications, chat persistence, and admin access to contact data. The project was recently customized to remove Emergent branding and replace it with local assets so the app is self-contained and reference-free from the old setup.
