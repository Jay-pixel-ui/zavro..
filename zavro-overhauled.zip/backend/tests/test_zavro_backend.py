"""Backend regression tests for Zavro API.

Covers: health, stats, contact (create/list/validation), chat (single + multi-turn),
chat history, and _id leak verification across responses.
"""
import os
import time
import uuid
import requests
import pytest

BASE_URL = os.environ.get(
    "REACT_APP_BACKEND_URL", "https://automation-lab-22.preview.emergentagent.com"
).rstrip("/")
API = f"{BASE_URL}/api"


# -------- Health & basic --------
class TestHealth:
    def test_root(self, api_client):
        r = api_client.get(f"{API}/")
        assert r.status_code == 200
        body = r.json()
        assert body.get("status") == "ok"
        assert "message" in body

    def test_health(self, api_client):
        r = api_client.get(f"{API}/health")
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ok"
        assert body["resend_configured"] is False
        assert body["llm_configured"] is True

    def test_stats(self, api_client):
        r = api_client.get(f"{API}/stats")
        assert r.status_code == 200
        body = r.json()
        for k in ("projects", "automations", "clients", "uptime"):
            assert k in body, f"missing {k}"
        assert isinstance(body["projects"], int)
        assert isinstance(body["automations"], int)
        assert isinstance(body["clients"], int)
        assert isinstance(body["uptime"], (int, float))


# -------- Contact --------
class TestContact:
    def test_create_contact_minimal(self, api_client):
        payload = {
            "name": "TEST_User",
            "email": "test_user@example.com",
            "message": "TEST_minimal message",
        }
        r = api_client.post(f"{API}/contact", json=payload)
        assert r.status_code == 200, r.text
        data = r.json()
        assert "id" in data and isinstance(data["id"], str) and len(data["id"]) > 10
        assert data["name"] == payload["name"]
        assert data["email"] == payload["email"]
        assert data["message"] == payload["message"]
        assert data["email_sent"] is False  # No Resend key
        assert "_id" not in data
        assert "created_at" in data

    def test_create_contact_full(self, api_client):
        payload = {
            "name": "TEST_FullUser",
            "email": "test_full@example.com",
            "company": "TEST Corp",
            "service": "AI Automation",
            "message": "TEST_full message with company and service",
        }
        r = api_client.post(f"{API}/contact", json=payload)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["company"] == "TEST Corp"
        assert data["service"] == "AI Automation"
        assert data["email_sent"] is False

    def test_list_contacts_sorted_newest_first(self, api_client):
        # Create two contacts and verify ordering
        a = {"name": "TEST_A", "email": "test_a@example.com", "message": "TEST_A msg"}
        r1 = api_client.post(f"{API}/contact", json=a)
        assert r1.status_code == 200
        id_a = r1.json()["id"]
        time.sleep(1.1)
        b = {"name": "TEST_B", "email": "test_b@example.com", "message": "TEST_B msg"}
        r2 = api_client.post(f"{API}/contact", json=b)
        assert r2.status_code == 200
        id_b = r2.json()["id"]

        r = api_client.get(f"{API}/contact", headers={"X-Admin-Key": "zavro-admin-2026"})
        assert r.status_code == 200
        items = r.json()
        assert isinstance(items, list)
        assert len(items) >= 2
        # Ensure no _id leak
        for it in items:
            assert "_id" not in it
        ids = [it["id"] for it in items]
        # Newest first => id_b should appear before id_a
        assert ids.index(id_b) < ids.index(id_a), f"Expected {id_b} before {id_a} in {ids[:5]}"

    def test_contact_invalid_email(self, api_client):
        payload = {"name": "TEST_X", "email": "not-an-email", "message": "TEST msg"}
        r = api_client.post(f"{API}/contact", json=payload)
        assert 400 <= r.status_code < 500, r.text

    def test_contact_missing_fields(self, api_client):
        # missing message
        r = api_client.post(f"{API}/contact", json={"name": "TEST", "email": "x@y.com"})
        assert 400 <= r.status_code < 500
        # missing name
        r2 = api_client.post(f"{API}/contact", json={"email": "x@y.com", "message": "hi"})
        assert 400 <= r2.status_code < 500
        # empty name
        r3 = api_client.post(f"{API}/contact", json={"name": "", "email": "x@y.com", "message": "hi"})
        assert 400 <= r3.status_code < 500


# -------- Chat --------
class TestChat:
    def test_chat_single_turn(self, api_client):
        session_id = f"TEST_{uuid.uuid4()}"
        r = api_client.post(
            f"{API}/chat",
            json={"session_id": session_id, "message": "Hello NOVA, what services does Zavro offer? Reply briefly."},
            timeout=60,
        )
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["session_id"] == session_id
        assert isinstance(body["reply"], str)
        assert len(body["reply"]) > 5

    def test_chat_history_and_persistence(self, api_client):
        session_id = f"TEST_{uuid.uuid4()}"
        r1 = api_client.post(
            f"{API}/chat",
            json={"session_id": session_id, "message": "My favorite color is teal. Remember it. Reply briefly."},
            timeout=60,
        )
        assert r1.status_code == 200, r1.text

        # History should contain at least user + assistant
        h = api_client.get(f"{API}/chat/{session_id}/history")
        assert h.status_code == 200
        msgs = h.json()
        assert isinstance(msgs, list)
        assert len(msgs) >= 2
        roles = [m["role"] for m in msgs]
        assert "user" in roles and "assistant" in roles
        for m in msgs:
            assert "_id" not in m
            assert "text" in m and "created_at" in m
        # ordering ascending
        timestamps = [m["created_at"] for m in msgs]
        assert timestamps == sorted(timestamps)

    def test_chat_multi_turn_context(self, api_client):
        session_id = f"TEST_{uuid.uuid4()}"
        r1 = api_client.post(
            f"{API}/chat",
            json={"session_id": session_id, "message": "Remember the code word: ORION-9. Acknowledge briefly."},
            timeout=60,
        )
        assert r1.status_code == 200, r1.text
        time.sleep(1)
        r2 = api_client.post(
            f"{API}/chat",
            json={"session_id": session_id, "message": "What was the code word I just told you? Reply with it."},
            timeout=60,
        )
        assert r2.status_code == 200, r2.text
        reply2 = r2.json()["reply"]
        assert "ORION" in reply2.upper(), f"Expected context retention. Got: {reply2}"

        # History should have at least 4 messages now
        h = api_client.get(f"{API}/chat/{session_id}/history")
        assert h.status_code == 200
        msgs = h.json()
        assert len(msgs) >= 4

    def test_chat_validation_empty_message(self, api_client):
        r = api_client.post(
            f"{API}/chat", json={"session_id": f"TEST_{uuid.uuid4()}", "message": ""}
        )
        assert 400 <= r.status_code < 500


# -------- _id leak guard across all list endpoints --------
class TestNoIdLeak:
    def test_no_id_in_contacts_list(self, api_client):
        r = api_client.get(f"{API}/contact", headers={"X-Admin-Key": "zavro-admin-2026"})
        assert r.status_code == 200
        for it in r.json():
            assert "_id" not in it

    def test_no_id_in_chat_history(self, api_client):
        # create a session
        sid = f"TEST_{uuid.uuid4()}"
        api_client.post(f"{API}/chat", json={"session_id": sid, "message": "Ping. Reply short."}, timeout=60)
        r = api_client.get(f"{API}/chat/{sid}/history")
        assert r.status_code == 200
        for m in r.json():
            assert "_id" not in m



# -------- Admin auth on GET /api/contact --------
ADMIN_KEY = "zavro-admin-2026"


class TestAdminAuth:
    def test_get_contact_without_header_returns_401(self, api_client):
        r = api_client.get(f"{API}/contact")
        assert r.status_code == 401, r.text

    def test_get_contact_with_wrong_key_returns_401(self, api_client):
        r = api_client.get(f"{API}/contact", headers={"X-Admin-Key": "wrong-key"})
        assert r.status_code == 401, r.text

    def test_get_contact_with_correct_key_returns_200(self, api_client):
        r = api_client.get(f"{API}/contact", headers={"X-Admin-Key": ADMIN_KEY})
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)
        for it in data:
            assert "_id" not in it


# -------- Chat brevity (system prompt update) --------
class TestChatBrevity:
    QUERIES = [
        "Tell me about your website service",
        "How much does branding cost?",
        "Hi",
    ]

    @pytest.mark.parametrize("query", QUERIES)
    def test_chat_response_is_concise_no_markdown(self, api_client, query):
        session_id = f"TEST_brevity_{uuid.uuid4()}"
        r = api_client.post(
            f"{API}/chat",
            json={"session_id": session_id, "message": query},
            timeout=60,
        )
        assert r.status_code == 200, r.text
        reply = r.json()["reply"]
        assert isinstance(reply, str) and len(reply) > 0
        # No markdown headers
        for header in ("## ", "### ", "#### "):
            assert header not in reply, f"Markdown header '{header.strip()}' found in reply: {reply!r}"
        # Also block leading '# ' header line
        for line in reply.splitlines():
            assert not line.lstrip().startswith("# "), f"Markdown H1 line in reply: {line!r}"
        # Word count < 100
        word_count = len(reply.split())
        assert word_count < 100, f"Reply too long ({word_count} words) for '{query}': {reply!r}"

@pytest.fixture
def api_client():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s
