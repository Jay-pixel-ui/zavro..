import os
from openai import OpenAI

# 1. PUT YOUR ACTUAL KEY HERE
MY_KEY = "sk-your-actual-openai-key-here"

def test_ai():
    print("Testing OpenAI Connection...")
    try:
        # Initialize the client
        client = OpenAI(api_key=MY_KEY)
        
        # Simple request to see if it works
        response = client.chat.completions.create(
            model="gpt-4o", 
            messages=[{"role": "user", "content": "Hello! Are you online?"}],
            max_tokens=10
        )
        
        print("\n✅ SUCCESS!")
        print(f"AI Response: {response.choices[0].message.content}")
        
    except Exception as e:
        print("\n❌ FAILED!")
        print(f"Error: {e}")

if __name__ == "__main__":
    test_ai()
