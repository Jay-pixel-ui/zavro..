"""
Zavro Solutions Pte Ltd — Backend API
FastAPI + MongoDB (Motor) + OpenAI-powered NOVA concierge.

Run:  uvicorn server:app --reload --port 8000
"""

from __future__ import annotations

import html
import logging
import os
import re
import secrets
import time
import uuid
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Deque, Dict, List, Optional

from dotenv import load_dotenv
from fastapi import APIRouter, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from openai import AsyncOpenAI
from pydantic import BaseModel, EmailStr, Field
from starlette.concurrency import run_in_threadpool

import resend

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-8s | %(message)s")
logger = logging.getLogger("zavro")

# ---------------------------------------------------------------------------
# Environment
# ---------------------------------------------------------------------------
MONGO_URL = os.environ.get("MONGO_URL", "")
DB_NAME = os.environ.get("DB_NAME", "zavro_db")

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")

RESEND_API_KEY = os.environ.get("RESEND_API_KEY", "")
SENDER_EMAIL = os.environ.get("SENDER_EMAIL", "onboarding@resend.dev")
NOTIFICATION_EMAIL = os.environ.get("NOTIFICATION_EMAIL", "")

ADMIN_KEY = os.environ.get("ADMIN_KEY", "")

CORS_ORIGINS = [o.strip() for o in os.environ.get("CORS_ORIGINS", "http://localhost:3000").split(",") if o.strip()]

if RESEND_API_KEY:
    resend.api_key = RESEND_API_KEY

openai_client: Optional[AsyncOpenAI] = AsyncOpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

if not OPENAI_API_KEY:
    logger.warning("OPENAI_API_KEY not set — NOVA will run in fallback mode.")
if not MONGO_URL:
    logger.warning("MONGO_URL not set — running without persistence.")
if not ADMIN_KEY:
    logger.warning("ADMIN_KEY not set — /api/contact (admin) is locked until it is configured.")

# ---------------------------------------------------------------------------
# NOVA persona
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """You are NOVA, the AI growth strategist for Zavro Solutions Pte Ltd — a premium digital growth and IT solutions agency based in Singapore, serving founders, CMOs and operators worldwide.

Zavro's disciplines: Website Development, Branding & Logo Design, Marketing Solutions, Social Media Management, Business Consultancy, and AI Automation & Integrations.

VOICE: a senior strategist in a Marina Bay boardroom — sharp, composed, quietly confident, a little dry-witted. Never chatty, never sycophantic, never generic-chatbot. You respect the reader's time and their intelligence.

HARD RULES:
- Under 70 words, always. Plain prose only — no markdown, no headers, no bullet points, no asterisks, no emoji.
- Never invent statistics, client names, dates or case studies. If you do not know something specific, say so plainly and offer to connect them with a strategist.
- Never quote a price. Pricing is scoped after a free consultation — say that plainly if asked.
- If asked whether you are human, say clearly that you are NOVA, Zavro's AI strategist.
- Never disparage competitors by name.
- Close most replies by moving things forward — a sharp follow-up question, or a nudge toward booking a consultation.

A touch of wit is welcome. Competence always comes first."""

MAX_REPLY_WORDS = 70

# ---------------------------------------------------------------------------
# Rate limiting (in-memory sliding window — swap for Redis at multi-instance scale)
# ---------------------------------------------------------------------------
RATE_LIMIT = 20
RATE_WINDOW_SECONDS = 60
_rate_buckets: Dict[str, Deque[float]] = defaultdict(deque)


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def _check_rate_limit(key: str) -> bool:
    now = time.time()
    bucket = _rate_buckets[key]
    while bucket and now - bucket[0] > RATE_WINDOW_SECONDS:
        bucket.popleft()
    if len(bucket) >= RATE_LIMIT:
        return False
    bucket.append(now)
    return True


def _sanitize_reply(text: str, max_words: int = MAX_REPLY_WORDS) -> str:
    """Defense-in-depth: strip stray markdown and hard-cap length server-side
    so NOVA's brevity/no-markdown rules hold even if the model drifts."""
    text = re.sub(r"[#*_`>]+", "", text)
    text = re.sub(r"^\s*[-•]\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"\s*\n+\s*", " ", text).strip()

    words = text.split()
    if len(words) > max_words:
        clipped = " ".join(words[:max_words])
        cut = max(clipped.rfind("."), clipped.rfind("!"), clipped.rfind("?"))
        text = clipped[: cut + 1] if cut > 40 else clipped.rstrip(",;: ") + "…"
    return text.strip()


async def _generate_reply(user_text: str, history: List[dict]) -> str:
    if openai_client is None:
        return (
            "NOVA's AI layer isn't wired up yet on this deployment. Drop your details in the "
            "contact form below and a strategist will follow up personally."
        )

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    for m in history[-12:]:
        role = "assistant" if m.get("role") == "assistant" else "user"
        content = (m.get("text") or "").strip()
        if content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": user_text})

    try:
        completion = await openai_client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=messages,
            max_tokens=260,
            temperature=0.8,
            presence_penalty=0.3,
        )
        raw = (completion.choices[0].message.content or "").strip()
        return _sanitize_reply(raw) if raw else "Tell me a bit more about what you're building — I'll take it from there."
    except Exception as exc:  # noqa: BLE001 — external API, never leak internals to the client
        logger.error("OpenAI call failed: %s", exc)
        return "NOVA hit a snag on that one. Try rephrasing, or use the contact form and a strategist will step in directly."


# ---------------------------------------------------------------------------
# Mongo lifecycle
# ---------------------------------------------------------------------------
mongo_client: Optional[AsyncIOMotorClient] = None
db = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global mongo_client, db
    if MONGO_URL:
        mongo_client = AsyncIOMotorClient(MONGO_URL)
        db = mongo_client[DB_NAME]
        try:
            await db.contacts.create_index("created_at")
            await db.chat_messages.create_index([("session_id", 1), ("created_at", 1)])
            logger.info("MongoDB connected — database '%s'", DB_NAME)
        except Exception as exc:  # noqa: BLE001
            logger.error("MongoDB index setup failed: %s", exc)
    yield
    if mongo_client is not None:
        mongo_client.close()


app = FastAPI(title="Zavro Solutions API", version="2.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials="*" not in CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)

api = APIRouter(prefix="/api")

# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
class ContactCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=120)
    email: EmailStr
    company: Optional[str] = Field(default=None, max_length=120)
    service: Optional[str] = Field(default=None, max_length=120)
    message: str = Field(..., min_length=1, max_length=3000)


class ContactOut(BaseModel):
    id: str
    name: str
    email: EmailStr
    company: Optional[str] = None
    service: Optional[str] = None
    message: str
    email_sent: bool
    created_at: datetime


class ChatRequest(BaseModel):
    session_id: Optional[str] = Field(default=None, max_length=120)
    message: str = Field(..., min_length=1, max_length=1000)


class ChatResponse(BaseModel):
    session_id: str
    reply: str


class ChatMessageOut(BaseModel):
    role: str
    text: str
    created_at: datetime


# ---------------------------------------------------------------------------
# Contact endpoints
# ---------------------------------------------------------------------------
def _send_contact_email_sync(doc: dict) -> bool:
    try:
        safe_name = html.escape(doc["name"])
        safe_email = html.escape(doc["email"])
        safe_company = html.escape(doc["company"] or "—")
        safe_service = html.escape(doc["service"] or "General Inquiry")
        safe_message = html.escape(doc["message"]).replace("\n", "<br/>")
        resend.Emails.send(
            {
                "from": SENDER_EMAIL,
                "to": [NOTIFICATION_EMAIL],
                "reply_to": doc["email"],
                "subject": f"New enquiry — {safe_name} ({safe_service})",
                "html": f"""
                <div style="font-family:Arial,sans-serif;background:#02040A;color:#ffffff;padding:28px;border-radius:12px;">
                  <h2 style="color:#00E5FF;margin:0 0 16px;">New Zavro Enquiry</h2>
                  <p style="margin:6px 0;"><strong>Name:</strong> {safe_name}</p>
                  <p style="margin:6px 0;"><strong>Email:</strong> {safe_email}</p>
                  <p style="margin:6px 0;"><strong>Company:</strong> {safe_company}</p>
                  <p style="margin:6px 0;"><strong>Service:</strong> {safe_service}</p>
                  <p style="margin:16px 0 6px;"><strong>Message:</strong></p>
                  <p style="margin:0;line-height:1.6;">{safe_message}</p>
                </div>
                """,
            }
        )
        return True
    except Exception as exc:  # noqa: BLE001
        logger.error("Resend email failed: %s", exc)
        return False


@api.post("/contact", response_model=ContactOut, status_code=201)
async def create_contact(payload: ContactCreate) -> ContactOut:
    now = datetime.now(timezone.utc)
    doc = {
        "id": str(uuid.uuid4()),
        "name": payload.name.strip(),
        "email": payload.email,
        "company": (payload.company or "").strip() or None,
        "service": (payload.service or "").strip() or None,
        "message": payload.message.strip(),
        "email_sent": False,
        "created_at": now,
    }

    if db is not None:
        await db.contacts.insert_one(doc)

    if RESEND_API_KEY and NOTIFICATION_EMAIL:
        doc["email_sent"] = await run_in_threadpool(_send_contact_email_sync, doc)
        if db is not None and doc["email_sent"]:
            await db.contacts.update_one({"id": doc["id"]}, {"$set": {"email_sent": True}})

    return ContactOut(**doc)


@api.get("/contact", response_model=List[ContactOut])
async def list_contacts(x_admin_key: Optional[str] = Header(default=None)) -> List[ContactOut]:
    if not ADMIN_KEY or not x_admin_key or not secrets.compare_digest(x_admin_key, ADMIN_KEY):
        raise HTTPException(status_code=401, detail="Unauthorized")
    if db is None:
        return []
    cursor = db.contacts.find({}, {"_id": 0}).sort("created_at", -1).limit(500)
    return [ContactOut(**doc) async for doc in cursor]


# ---------------------------------------------------------------------------
# Chat endpoints
# ---------------------------------------------------------------------------
@api.post("/chat", response_model=ChatResponse)
async def chat(payload: ChatRequest, request: Request) -> ChatResponse:
    if not _check_rate_limit(_client_ip(request)):
        raise HTTPException(status_code=429, detail="Too many messages — give NOVA a moment and try again shortly.")

    session_id = payload.session_id or str(uuid.uuid4())
    user_text = payload.message.strip()
    if not user_text:
        raise HTTPException(status_code=422, detail="Message cannot be empty.")

    history: List[dict] = []
    if db is not None:
        cursor = db.chat_messages.find({"session_id": session_id}, {"_id": 0}).sort("created_at", 1).limit(20)
        history = [doc async for doc in cursor]

    reply_text = await _generate_reply(user_text, history)
    now = datetime.now(timezone.utc)

    if db is not None:
        await db.chat_messages.insert_many(
            [
                {"session_id": session_id, "role": "user", "text": user_text, "created_at": now},
                {"session_id": session_id, "role": "assistant", "text": reply_text, "created_at": now},
            ]
        )

    return ChatResponse(session_id=session_id, reply=reply_text)


@api.get("/chat/{session_id}/history", response_model=List[ChatMessageOut])
async def chat_history(session_id: str) -> List[ChatMessageOut]:
    if db is None:
        return []
    cursor = db.chat_messages.find({"session_id": session_id}, {"_id": 0}).sort("created_at", 1).limit(100)
    return [ChatMessageOut(**doc) async for doc in cursor]


# ---------------------------------------------------------------------------
# Meta endpoints
# ---------------------------------------------------------------------------
@api.get("/")
async def root() -> dict:
    return {"status": "ok", "message": "Zavro Solutions API — online."}


@api.get("/health")
async def health() -> dict:
    db_ok = False
    if mongo_client is not None:
        try:
            await mongo_client.admin.command("ping")
            db_ok = True
        except Exception:  # noqa: BLE001
            db_ok = False
    return {
        "status": "ok",
        "db_connected": db_ok,
        "llm_configured": openai_client is not None,
        "resend_configured": bool(RESEND_API_KEY and NOTIFICATION_EMAIL),
    }


@api.get("/stats")
async def stats() -> dict:
    return {"projects": 84, "automations": 320, "clients": 47, "uptime": 99.98}


app.include_router(api)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("server:app", host="0.0.0.0", port=int(os.environ.get("PORT", 8000)), reload=False)
