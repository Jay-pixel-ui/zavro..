# Zavro Project Prompt for AI Tooling

You are working with the Zavro project, a full-stack AI automation and digital growth agency website.

## Project Overview
- Frontend: React app built with CRACO, Tailwind CSS, Framer Motion, React Router, Axios, and Radix-style UI components.
- Backend: FastAPI app with MongoDB persistence, contact form handling, email sending via Resend, and an AI chat assistant powered by an LLM integration.
- Goal: deliver a polished landing page experience, secure contact intake, AI concierge chat, and admin contact review.

## Repository Layout
- Root contains README.md, design_guidelines.json, full_project_dump.txt, backend/, frontend/, memory/, tests/, and test_reports/.
- Backend entry point: backend/server.py
- Frontend entry point: frontend/src/index.js
- Main app component: frontend/src/App.js
- Shared constants and assets: frontend/src/lib/constants.js
- CRACO config: frontend/craco.config.js
- Public HTML shell: frontend/public/index.html
- Local assets: frontend/public/favicon.svg and frontend/public/images/*

## Important Files
- backend/server.py
  - Main FastAPI app
  - Loads env vars
  - Connects to MongoDB
  - Defines models for contacts and chat
  - Exposes /api routes for health, stats, contact, chat, and chat history
  - Stores chat history per session
  - Uses admin key for contact listing
- backend/requirements.txt
  - Python dependencies for backend
- backend/tests/test_zavro_backend.py
  - Regression tests for health, stats, contact, chat, history, and no-_id leak behavior
- frontend/src/App.js
  - Mounts the landing page sections and routes
- frontend/src/components/AIChatBubble.jsx
  - Floating chat assistant UI
  - Sends requests to /api/chat
  - Uses REACT_APP_BACKEND_URL
  - Maintains session_storage-based session_id
- frontend/src/lib/constants.js
  - Shared constants and asset URLs
  - Currently points to local SVG assets instead of Emergent-hosted assets
- frontend/public/index.html
  - HTML shell for the app
  - No longer contains the old Emergent badge/watermark injection
- frontend/package.json
  - Scripts: start/build/test
  - Uses CRACO

## Environment Variables
Backend:
- MONGO_URL (required)
- DB_NAME (required)
- EMERGENT_LLM_KEY (optional; chat endpoint returns 503 if missing)
- RESEND_API_KEY (optional)
- SENDER_EMAIL (optional)
- NOTIFICATION_EMAIL (optional)
- ADMIN_KEY (optional; defaults to zavro-admin-2026)
- CORS_ORIGINS (optional)
Frontend:
- REACT_APP_BACKEND_URL (required for the chat component)

## Runtime Behavior
- Frontend dev server should run on http://localhost:3000 or http://127.0.0.1:3000
- Backend should run on http://localhost:8000 or the configured host/port
- The frontend uses the backend for contact submission and AI chat
- The AI chat assistant is called NOVA
- The chat flow preserves session history across turns
- Contact listing is admin-protected

## Current Customization State
- The project was adapted to remove visible Emergent badge/watermark references.
- Emergent-specific visual edits integration was removed from the frontend config.
- Emergent-hosted assets were replaced with local SVG assets.
- A local favicon was added.
- The app shell is now self-contained and no longer depends on the old Emergent UI injection.

## Verification
- The frontend production build was verified successfully with: npm run build
- Result: Compiled successfully.

## What to Preserve
- Local asset approach in frontend/src/lib/constants.js
- Removal of Emergent UI injection from frontend/public/index.html
- Local favicon and image assets in frontend/public/
- Backend API behavior in backend/server.py
- AI chat behavior in frontend/src/components/AIChatBubble.jsx

## What to Avoid
- Reintroducing Emergent badge/watermark code
- Reintroducing external Emergent asset URLs into the frontend
- Breaking the contact form or AI chat flow
- Exposing MongoDB _id values in API responses

## Short Working Summary
Zavro is a polished marketing website with a React frontend and FastAPI backend. The frontend offers animated landing sections, a floating AI assistant, and admin access; the backend handles contact submissions, email delivery, chat persistence, and admin-only contact listing. The project was recently cleaned up to be free from the old Emergent branding and asset references.
